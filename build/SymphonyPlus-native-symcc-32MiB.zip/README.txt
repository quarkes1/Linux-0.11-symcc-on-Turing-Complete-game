SymphonyPlus 原生 symcc / 32 MiB

先验容量：RAM=capacity-probe.bin，DiskA=capacity-disk.bin。
两者均设 32 MiB、Big endian；屏幕应显示 RAM 32M PASS 和 DISK 32M PASS。
ALIAS 表示游戏硬件高地址回绕，需要检查地址线。测试盘与系统盘分开。

启动系统：RAM=kernel.bin，DiskA=rootfs.bin，两者均 32 MiB、Big endian。
屏幕连接主 RAM；键盘沿用现有输入。显示详细启动日志，Welcome 后清屏进入 shell。

cd /tmp
cat > main.c <<EOF
#include <stdio.h>
int main(void) { puts("Hello from native symcc!"); return 0; }
EOF
symcc main.c -o main && ./main
sync
reset

支持 &&、||、;、mkdir、rm、ls -la、重定向和 heredoc。
Ctrl+C 取消当前输入、heredoc 或前台程序；新编译的纯计算循环也能响应。
symcc 显示预处理/编译/链接阶段；取消时清理临时文件并保留旧输出。
Shift+, 输入 <；Backspace 删除，Enter 提交。
symcc 支持单源文件、-o、-I；默认输出 a.out，文件名每段最多14字节。
详细 C 功能见 docs/symcc-c-support.md；性能与取消验证见 docs/superpowers/。
其他选项报错，失败保留原输出。标准 SDK 在 /include 与 /lib。
最多8进程、每进程2 MiB窗口、64 KiB栈；没有浮点或真正64位整数。

用户已确认容量配置修复乱码；本次性能与Ctrl+C更新的实际游戏运行仍需复验。
请使用解包后的绝对路径连接外部 bin。要保留游戏中的修改，请另存磁盘副本；构建会重建 rootfs。
